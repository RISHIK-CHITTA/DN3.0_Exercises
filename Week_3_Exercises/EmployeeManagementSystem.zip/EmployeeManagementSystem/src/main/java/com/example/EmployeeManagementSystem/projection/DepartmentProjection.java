package com.example.employeemanagementsystem.projection;

public interface DepartmentProjection {
    Long getDepartmentId();
    String getDepartmentName();
}
