package com.example.employeemanagementsystem.projection;

public interface EmployeeProjection {
    Long getEmployeeId();
    String getFullName();
    String getEmailAddress();
}
