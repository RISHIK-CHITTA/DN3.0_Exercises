package FactoryMethodPatternExample;

public class WordDocument implements Document{
    public void Writing(){
        System.out.println("I am Writing in Word Documents");
    }
}