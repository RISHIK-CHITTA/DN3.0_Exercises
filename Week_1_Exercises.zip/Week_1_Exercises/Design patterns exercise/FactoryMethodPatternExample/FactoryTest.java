package FactoryMethodPatternExample;

public class FactoryTest {
    public static void main(String args[]){
        FactoryWordDocument w=new FactoryWordDocument();
        w.createDocument();
        
    }
    
}
