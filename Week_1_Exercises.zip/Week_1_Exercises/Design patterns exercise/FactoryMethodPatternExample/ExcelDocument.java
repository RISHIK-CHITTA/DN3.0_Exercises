package FactoryMethodPatternExample;

public class ExcelDocument implements Document{
    public void Writing(){
        System.out.println("I am Writing in Excel Documents");
    }
}
