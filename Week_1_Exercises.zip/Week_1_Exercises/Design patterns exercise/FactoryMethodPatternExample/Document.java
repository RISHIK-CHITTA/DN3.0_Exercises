package FactoryMethodPatternExample;

public interface Document {
    public void Writing();
    
}

