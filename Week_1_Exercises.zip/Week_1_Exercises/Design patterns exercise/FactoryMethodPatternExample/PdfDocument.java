package FactoryMethodPatternExample;

public class PdfDocument implements Document{
    public void Writing(){
        System.out.println("I am Writing in Pdf Documents");
    }
}